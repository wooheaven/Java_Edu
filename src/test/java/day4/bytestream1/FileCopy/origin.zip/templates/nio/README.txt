Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds a Non-Blocking IO (NIO) connector for HTTP
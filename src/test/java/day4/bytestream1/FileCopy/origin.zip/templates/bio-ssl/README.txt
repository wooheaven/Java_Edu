Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds a Blocking IO (BIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration
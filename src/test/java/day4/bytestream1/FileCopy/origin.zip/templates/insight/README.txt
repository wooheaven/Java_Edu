Version: 1.8.3.RELEASE
Build Date: 20120417152453

* Adds Spring Insight Developer Edition
	* Insight Dashboard accessible at /insight
	* Standard collection plugins
* Sets Xmx to 1024M
* Sets MaxPermGen to 256M for Hotspot VMs
* Sets java.awt.headless to true

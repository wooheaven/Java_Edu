Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds asynchronous logging
Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds a Non-Blocking IO (NIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL configuration
Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds a Blocking IO (BIO) connector for HTTP
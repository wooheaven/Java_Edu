Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Disable SSLv2 for APR/native (APR) connector by setting SSLProtocol to TLSv1

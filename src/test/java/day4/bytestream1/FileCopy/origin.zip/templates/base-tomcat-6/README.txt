Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds Tomcat 6-specific ServerLifecycleListener
* Adds Tomcat 6-specific default catalina.policy to be used when starting with the -security option
* Adds Tomcat 6-specific JspServlet configuration
* Adds Tomcat 6-specific web-app declaration

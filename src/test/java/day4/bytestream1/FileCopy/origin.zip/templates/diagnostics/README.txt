Version: 2.8.2.RELEASE
Build Date: 20130124220529

* Adds a JDBC resource that integrates with request diagnostics to report slow queries
* Adds a ThreadDiagnosticsValve at the Engine level to report slow running requests